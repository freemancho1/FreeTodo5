package com.freeman.freetodo3.todo.group.model;

import android.arch.persistence.room.ColumnInfo;
import android.arch.persistence.room.Entity;
import android.arch.persistence.room.Index;
import android.arch.persistence.room.PrimaryKey;

@Entity(
        tableName = "tbl_todogroups",
        indices = {
                @Index(value = {"name"}),
                @Index(value = {"parent_id", "name"}, unique = true)
        }
)
public class TodoGroup {

    public TodoGroup(
            String name, String memo, int color,
            long parentId, int depth, int sequence, int isFavorite) {
        this.name = name;
        this.memo = memo;
        this.color = color;
        this.parentId = parentId;
        this.depth = depth;
        this.sequence = sequence;
        this.isFavorite = isFavorite;
    }

    public TodoGroup() { }
    public TodoGroup(long id) {
        this.id = id;
    }
    public TodoGroup(String name, long parentId) {
        this.name = name;
        this.parentId = parentId;
    }

    @PrimaryKey(autoGenerate = true)
    private long                id;

    private String              name;
    private String              memo;
    private int                 color;
    @ColumnInfo(name = "parent_id")
    private long                parentId;
    private int                 depth;
    private int                 sequence;
    @ColumnInfo(name = "is_children")
    private int                 isChildren;
    @ColumnInfo(name = "is_favorite")
    private int                 isFavorite;
    @ColumnInfo(name = "is_delete")
    private int                 isDelete;

    @Override
    public String toString() {
        return "TodoGroup{" +
                "id=" + id +
                ", name='" + name + '\'' +
                ", memo='" + memo + '\'' +
                ", color=" + color +
                ", parentId=" + parentId +
                ", depth=" + depth +
                ", sequence=" + sequence +
                ", isChildren=" + isChildren +
                ", isFavorite=" + isFavorite +
                ", isDelete=" + isDelete +
                '}';
    }

    public long getId() {
        return id;
    }

    public void setId(long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getMemo() {
        return memo;
    }

    public void setMemo(String memo) {
        this.memo = memo;
    }

    public int getColor() {
        return color;
    }

    public void setColor(int color) {
        this.color = color;
    }

    public long getParentId() {
        return parentId;
    }

    public void setParentId(long parentId) {
        this.parentId = parentId;
    }

    public int getDepth() {
        return depth;
    }

    public void setDepth(int depth) {
        this.depth = depth;
    }

    public int getSequence() {
        return sequence;
    }

    public void setSequence(int sequence) {
        this.sequence = sequence;
    }

    public boolean isChildren() {
        return isChildren == 1;
    }
    public int getIsChildren() {
        return isChildren;
    }

    public void setIsChildren(int isChildren) {
        this.isChildren = isChildren;
    }

    public boolean isFavorite() { return isFavorite == 1; }
    public int getIsFavorite() {
        return isFavorite;
    }

    public void setIsFavorite(int isFavorite) {
        this.isFavorite = isFavorite;
    }

    public boolean isDelete() { return isDelete == 1; }
    public int getIsDelete() {
        return isDelete;
    }

    public void setIsDelete(int isDelete) {
        this.isDelete = isDelete;
    }
}
