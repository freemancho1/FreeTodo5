package com.freeman.freetodo3.todo.group.view.adapter;

import com.freeman.freetodo3.todo.group.model.TodoGroup;
import com.multilevelview.models.RecyclerViewItem;

public class TodoGroupItem extends RecyclerViewItem {
    private TodoGroup todoGroup;

    public TodoGroupItem(int level) {
        super(level);
    }

    public TodoGroup getTodoGroup() {
        return todoGroup;
    }

    public void setTodoGroup(TodoGroup todoGroup) {
        this.todoGroup = todoGroup;
    }
}
