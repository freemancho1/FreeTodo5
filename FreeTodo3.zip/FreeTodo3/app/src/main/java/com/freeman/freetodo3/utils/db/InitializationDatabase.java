package com.freeman.freetodo3.utils.db;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;

import com.freeman.freetodo3.R;
import com.freeman.freetodo3.todo.group.model.TodoGroup;
import com.freeman.freetodo3.todo.group.model.TodoGroupRepository;

import java.util.ArrayList;
import java.util.List;

public class InitializationDatabase extends AppCompatActivity {
    private static final String LOG_TAG = "[INIT]";

    private TodoGroupRepository mTodoGroupRepo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.initialization_database);

        setTitle(R.string.initialize_db_title);

        mTodoGroupRepo = new TodoGroupRepository(getApplication());

        initTodoGroup();
    }


    private void initTodoGroup() {
        Button btnInitTodoGroup = findViewById(R.id.initialization_todogroup_button);
        btnInitTodoGroup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                addTodoGroup();
            }
        });
    }

    private void addTodoGroup() {
        mTodoGroupRepo.remove();

        List<TodoGroup> todoGroups = new ArrayList<>();

        todoGroups.add(new TodoGroup("팀업무", "팀과 관련된 업무 처리", 0xFF777777, 0, 0, 1, 1));
        todoGroups.add(new TodoGroup("연구개발", "연구개발과 관련된 업무 처리", 0xFF558888, 0, 0, 2, 0));
        todoGroups.add(new TodoGroup("회사업무", "팀 이외에 회사 전체와 관련된 업무 처리", 0xFF4444EE, 0, 0, 3, 0));
        todoGroups.add(new TodoGroup("사업지원", "사업부서 사업화 지원 업무 처리", 0xFF44DD44, 0, 0, 4, 1));

        mTodoGroupRepo.insert(todoGroups);
        List<TodoGroup> rootTodoGroups = mTodoGroupRepo.getChildren(0);

        List<TodoGroup> childTodoGroups = new ArrayList<>();

        TodoGroup r0 = rootTodoGroups.get(0);
        TodoGroup r1 = rootTodoGroups.get(1);
        TodoGroup r3 = rootTodoGroups.get(3);

        for (TodoGroup todoGroup: rootTodoGroups) {
            Log.d(LOG_TAG, todoGroup.toString());
        }
        Log.d(LOG_TAG, "===========================");

        childTodoGroups.add(new TodoGroup("주무","", 0xFF999999, r0.getId(), r0.getDepth()+1, 1, 1));
        childTodoGroups.add(new TodoGroup("예산담당","", 0xFF999999, r0.getId(), r0.getDepth()+1, 2, 0));
        childTodoGroups.add(new TodoGroup("품질담당","", 0xFF999999, r0.getId(), r0.getDepth()+1, 3, 0));
        childTodoGroups.add(new TodoGroup("보안담당","", 0xFF999999, r0.getId(), r0.getDepth()+1, 4, 0));

        childTodoGroups.add(new TodoGroup("인공지능 기반 보안관제 솔루션 개발","", 0xFF55AAAA, r1.getId(), r1.getDepth()+1, 1, 1));
        childTodoGroups.add(new TodoGroup("AI 챗봇 서비스 개발","", 0xFF55AAAA, r1.getId(), r1.getDepth()+1, 2, 0));
        childTodoGroups.add(new TodoGroup("지하시설물 관리를 위한 AR/VR 솔루션 개발","", 0xFF55AAAA, r1.getId(), r1.getDepth()+1, 3, 0));

        childTodoGroups.add(new TodoGroup("남동발전 전자결재 구축 사업","", 0xFF55AAAA, r3.getId(), r3.getDepth()+1, 1, 0));
        childTodoGroups.add(new TodoGroup("MDMS 구축 사업","", 0xFF55AAAA, r3.getId(), r3.getDepth()+1, 2, 0));
        childTodoGroups.add(new TodoGroup("MDMS 구축 사업","", 0xFF55AAAA, r3.getId(), r3.getDepth()+1, 3, 0));

        mTodoGroupRepo.insert(childTodoGroups);
        rootTodoGroups.get(0).setIsChildren(1);
        rootTodoGroups.get(1).setIsChildren(1);
        rootTodoGroups.get(3).setIsChildren(1);
        mTodoGroupRepo.update(rootTodoGroups);

        rootTodoGroups = mTodoGroupRepo.getChildren(r1.getId());
        childTodoGroups.clear();
        r0 = rootTodoGroups.get(0);
        r1 = rootTodoGroups.get(1);
        childTodoGroups.add(new TodoGroup("연구과제 수행전 처리작업","", 0xFFCCCCCC, r0.getId(), r0.getDepth()+1, 1, 0));
        childTodoGroups.add(new TodoGroup("연구과제 계획서 및 수행계획서 작성","", 0xFFCCCCCC, r0.getId(), r0.getDepth()+1, 2, 0));
        childTodoGroups.add(new TodoGroup("분석단계 수행","", 0xFFCCCCCC, r0.getId(), r0.getDepth()+1, 3, 0));
        childTodoGroups.add(new TodoGroup("용역 발주","", 0xFFCCCCCC, r0.getId(), r0.getDepth()+1, 4, 0));

        childTodoGroups.add(new TodoGroup("연구과제 수행전 처리작업","", 0xFFCCCCCC, r1.getId(), r1.getDepth()+1, 1, 0));
        childTodoGroups.add(new TodoGroup("연구과제 계획서 및 수행계획서 작성","", 0xFFCCCCCC, r1.getId(), r1.getDepth()+1, 2, 0));
        childTodoGroups.add(new TodoGroup("분석단계 수행","", 0xFFCCCCCC, r1.getId(), r1.getDepth()+1, 3, 0));

        mTodoGroupRepo.insert(childTodoGroups);
        rootTodoGroups.get(0).setIsChildren(1);
        rootTodoGroups.get(1).setIsChildren(1);
        mTodoGroupRepo.update(rootTodoGroups);

        List<TodoGroup> allTodoGroups = mTodoGroupRepo.get();
        for (TodoGroup todoGroup : allTodoGroups) {
            Log.d(LOG_TAG, todoGroup.toString());
        }
    }
}
