package com.freeman.freetodo3.todo.group.model.async;

import android.os.AsyncTask;

import com.freeman.freetodo3.todo.group.model.TodoGroup;
import com.freeman.freetodo3.todo.group.model.TodoGroupDao;
import com.freeman.freetodo3.todo.group.model.TodoGroupRepository;

public class SetTodoGroupAsyncTask extends AsyncTask<TodoGroup, Void, Void> {
    private final TodoGroupDao mDao;
    private final int mType;

    public SetTodoGroupAsyncTask(TodoGroupDao todoGroupDao, int type) {
        this.mDao = todoGroupDao;
        this.mType = type;
    }

    @Override
    protected Void doInBackground(TodoGroup... todoGroups) {

        switch (mType) {
            case TodoGroupRepository.INSERT_N:
                mDao.insert(todoGroups);
                break;
            case TodoGroupRepository.UPDATE_1:
                mDao.update(todoGroups[0]);
                break;
            case TodoGroupRepository.UPDATE_N:
                mDao.update(todoGroups);
                break;
            case TodoGroupRepository.REMOVE_1:
                mDao.remove(todoGroups[0]);
                break;
            case TodoGroupRepository.REMOVE_N:
                mDao.remove(todoGroups);
                break;
            case TodoGroupRepository.REMOVE_ALL:
                mDao.remove();
                break;
        }

        return null;
    }
}
