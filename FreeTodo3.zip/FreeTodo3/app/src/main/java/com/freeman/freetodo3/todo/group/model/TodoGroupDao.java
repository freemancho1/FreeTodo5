package com.freeman.freetodo3.todo.group.model;

import android.arch.persistence.room.Dao;
import android.arch.persistence.room.Delete;
import android.arch.persistence.room.Insert;
import android.arch.persistence.room.Query;
import android.arch.persistence.room.Update;

import java.util.List;

import static android.arch.persistence.room.OnConflictStrategy.REPLACE;

@Dao
public interface TodoGroupDao {

    @Query("SELECT * FROM tbl_todogroups ORDER BY id DESC")
    List<TodoGroup> get();
    @Query("SELECT * FROM tbl_todogroups WHERE id = :id")
    TodoGroup get(long id);
    @Query("SELECT * FROM tbl_todogroups WHERE name = :name AND parent_id = :parentId")
    TodoGroup get(String name, long parentId);

    @Query("SELECT * FROM tbl_todogroups WHERE parent_id = :parentId ORDER BY sequence ASC")
    List<TodoGroup> getByParentId(long parentId);

    // Return - todoGroup id;
    @Insert(onConflict = REPLACE)
    long insert(TodoGroup todoGroup);
    @Insert(onConflict = REPLACE)
    void insert(TodoGroup... todoGroups);

    @Update
    void update(TodoGroup todoGroup);
    @Update
    void update(TodoGroup... todoGroups);

    @Query("DELETE FROM tbl_todogroups")
    void remove();
    @Delete
    void remove(TodoGroup... todoGroups);
    @Delete
    void remove(TodoGroup todoGroup);
}
