package com.freeman.freetodo3.todo.group.model.async;

import android.os.AsyncTask;

import com.freeman.freetodo3.todo.group.model.TodoGroup;
import com.freeman.freetodo3.todo.group.model.TodoGroupDao;
import com.freeman.freetodo3.todo.group.model.TodoGroupRepository;

import java.util.List;

public class GetTodoGroupsAsyncTask extends AsyncTask<TodoGroup, Void, List<TodoGroup>> {
    private final TodoGroupDao mDao;
    private final int mType;

    public GetTodoGroupsAsyncTask(TodoGroupDao todoGroupDao, int type) {
        this.mDao = todoGroupDao;
        this.mType = type;
    }

    @Override
    protected List<TodoGroup> doInBackground(TodoGroup... todoGroups) {

        switch (mType) {
            case TodoGroupRepository.GET_N:
                return mDao.get();
            case TodoGroupRepository.GET_N_CHILDREN:
                return mDao.getByParentId(todoGroups[0].getParentId());
        }

        return null;
    }
}
