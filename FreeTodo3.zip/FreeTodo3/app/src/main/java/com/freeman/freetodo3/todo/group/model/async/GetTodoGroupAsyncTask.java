package com.freeman.freetodo3.todo.group.model.async;

import android.os.AsyncTask;

import com.freeman.freetodo3.todo.group.model.TodoGroup;
import com.freeman.freetodo3.todo.group.model.TodoGroupDao;
import com.freeman.freetodo3.todo.group.model.TodoGroupRepository;

import java.util.List;

public class GetTodoGroupAsyncTask extends AsyncTask<TodoGroup, Void, TodoGroup> {
    private final TodoGroupDao mDao;
    private final int mType;

    public GetTodoGroupAsyncTask(TodoGroupDao todoGroupDao, int type) {
        this.mDao = todoGroupDao;
        this.mType = type;
    }

    @Override
    protected TodoGroup doInBackground(TodoGroup... todoGroups) {

        switch (mType) {
            case TodoGroupRepository.GET_1:
                return mDao.get(todoGroups[0].getId());
            case TodoGroupRepository.GET_1_NAME:
                return mDao.get(todoGroups[0].getName(), todoGroups[0].getParentId());
        }

        return null;
    }
}
