package com.freeman.freetodo3.utils.db;

import android.app.Application;
import android.util.Log;

import com.freeman.freetodo3.todo.group.model.TodoGroup;
import com.freeman.freetodo3.todo.group.model.TodoGroupRepository;

import java.util.ArrayList;
import java.util.List;

public class TestDatabase {
    private static final String LOG_TAG = "[TEST]";

    private final TodoGroupRepository mTodoGroupRepo;

    public TestDatabase(Application application) {
        mTodoGroupRepo = new TodoGroupRepository(application);
    }

    public void TestTodoGroup() {
        mTodoGroupRepo.remove();

        TodoGroup insertTodoGroup = new TodoGroup("aaa", "aaaaaa", 0xFFFFFFFF, 0, 0, 0, 0);
        long groupId = mTodoGroupRepo.insert(insertTodoGroup);
        TodoGroup readTodoGroupById = mTodoGroupRepo.get(groupId);
        TodoGroup readTodoGroupByName = mTodoGroupRepo.get(insertTodoGroup.getName(), insertTodoGroup.getParentId());

        Log.d(LOG_TAG, String.valueOf(groupId));
        Log.d(LOG_TAG, insertTodoGroup.toString());
        Log.d(LOG_TAG, readTodoGroupById.toString());
        Log.d(LOG_TAG, readTodoGroupByName.toString());

        List<TodoGroup> insertTodoGroups = new ArrayList<>();
        insertTodoGroups.add(new TodoGroup("bbbb", "bbbbbb", 3, 0, 0, 0, 0));
        insertTodoGroups.add(new TodoGroup("cccc", "cccccccc", 3, 0, 0, 0, 0));
        insertTodoGroups.add(new TodoGroup("dddd", "ddddddddd", 3, 1, 0, 0, 0));
        insertTodoGroups.add(new TodoGroup("eeee", "eeeee", 3, 1, 0, 0, 0));
        mTodoGroupRepo.insert(insertTodoGroups);

        Log.d(LOG_TAG, "All TodoGroups-----------------------");
        List<TodoGroup> readAllTodoGroups = mTodoGroupRepo.get();
        for (TodoGroup todoGroup: readAllTodoGroups) {
            Log.d(LOG_TAG, todoGroup.toString());
        }

        Log.d(LOG_TAG, "Parent Id 1 TodoGroups---------------");
        List<TodoGroup> readChildrenTodoGroups = mTodoGroupRepo.getChildren((long)1);
        for (TodoGroup todoGroup: readChildrenTodoGroups) {
            Log.d(LOG_TAG, todoGroup.toString());
        }

        mTodoGroupRepo.delete(groupId);

        mTodoGroupRepo.delete(readChildrenTodoGroups);
        Log.d(LOG_TAG, "Delete Parent Id 1 TodoGroups--------");
        readAllTodoGroups = mTodoGroupRepo.get();
        for (TodoGroup todoGroup: readAllTodoGroups) {
            Log.d(LOG_TAG, todoGroup.toString());
        }

        mTodoGroupRepo.remove(groupId);
        mTodoGroupRepo.remove(readChildrenTodoGroups);
        Log.d(LOG_TAG, "Remove Parent Id 1 TodoGroups--------");
        readAllTodoGroups = mTodoGroupRepo.get();
        for (TodoGroup todoGroup: readAllTodoGroups) {
            Log.d(LOG_TAG, todoGroup.toString());
        }
    }
}
