package com.freeman.freetodo3.todo.group.view;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.LinearLayoutManager;

import com.freeman.freetodo3.R;
import com.freeman.freetodo3.todo.group.model.TodoGroup;
import com.freeman.freetodo3.todo.group.view.adapter.TodoGroupItem;
import com.freeman.freetodo3.todo.group.model.TodoGroupRepository;
import com.freeman.freetodo3.todo.group.view.adapter.TodoGroupManagerAdapter;
import com.multilevelview.MultiLevelRecyclerView;
import com.multilevelview.models.RecyclerViewItem;

import java.util.ArrayList;
import java.util.List;

public class TodoGroupManager extends AppCompatActivity {

    private TodoGroupRepository mTodoGroupRepo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.todogroup_manager_main_view);

        setTitle(R.string.todogroup_manager_title);

        mTodoGroupRepo = new TodoGroupRepository(getApplication());
        List<TodoGroupItem> items = (List<TodoGroupItem>) makeItems((long)0);

        final MultiLevelRecyclerView contentsView = findViewById(R.id.todogroup_manager_main_view);
        contentsView.setLayoutManager(new LinearLayoutManager(this));

        TodoGroupManagerAdapter adapter = new TodoGroupManagerAdapter(this, items, contentsView);
        contentsView.setAdapter(adapter);
        contentsView.setToggleItemOnClick(false);
        contentsView.setAccordion(false);
        contentsView.openTill(0,1,2,3);

    }

    private List<?> makeItems(long parentId) {
        List<RecyclerViewItem> items = new ArrayList<>();

        List<TodoGroup> todoGroups = mTodoGroupRepo.getChildren(parentId);

        for (TodoGroup todoGroup: todoGroups) {

            // Setting item level(= depth)
            TodoGroupItem item = new TodoGroupItem(todoGroup.getDepth());
            item.setTodoGroup(todoGroup);

            if (todoGroup.isChildren()) {
                item.addChildren((List<RecyclerViewItem>) makeItems(todoGroup.getId()));
            }

            items.add(item);
        }

        return items;
    }
}
