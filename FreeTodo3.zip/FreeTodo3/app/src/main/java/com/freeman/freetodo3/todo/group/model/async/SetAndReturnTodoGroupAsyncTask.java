package com.freeman.freetodo3.todo.group.model.async;

import android.os.AsyncTask;

import com.freeman.freetodo3.todo.group.model.TodoGroup;
import com.freeman.freetodo3.todo.group.model.TodoGroupDao;
import com.freeman.freetodo3.todo.group.model.TodoGroupRepository;

public class SetAndReturnTodoGroupAsyncTask extends AsyncTask<TodoGroup, Void, Long> {
    private final TodoGroupDao mDao;
    private final int mType;

    public SetAndReturnTodoGroupAsyncTask(TodoGroupDao todoGroupDao, int type) {
        this.mDao = todoGroupDao;
        this.mType = type;
    }

    @Override
    protected Long doInBackground(TodoGroup... todoGroups) {

        switch (mType) {
            case TodoGroupRepository.INSERT_1:
                return mDao.insert(todoGroups[0]);
        }

        return null;
    }

}
