package com.freeman.freetodo3.todo.group.model;

import android.app.Application;

import com.freeman.freetodo3.todo.group.model.async.GetTodoGroupAsyncTask;
import com.freeman.freetodo3.todo.group.model.async.GetTodoGroupsAsyncTask;
import com.freeman.freetodo3.todo.group.model.async.SetAndReturnTodoGroupAsyncTask;
import com.freeman.freetodo3.todo.group.model.async.SetTodoGroupAsyncTask;
import com.freeman.freetodo3.utils.db.AppDatabase;

import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.ExecutionException;

public class TodoGroupRepository {

    public static final int GET_N = 1001;
    public static final int GET_1 = 1002;
    public static final int GET_1_NAME = 1003;
    public static final int GET_N_CHILDREN = 1004;
    public static final int INSERT_1 = 2001;
    public static final int INSERT_N = 2002;
    public static final int UPDATE_1 = 3001;
    public static final int UPDATE_N = 3002;
    public static final int REMOVE_1 = 4001;
    public static final int REMOVE_N = 4002;
    public static final int REMOVE_ALL = 4003;

    private final TodoGroupDao mDao;

    public TodoGroupRepository(Application application) {
        AppDatabase database = AppDatabase.getInstance(application);
        mDao = database.todoGroupDao();
    }

    public List<TodoGroup> get() {
        TodoGroup tempTodoGroup = new TodoGroup();
        List<TodoGroup> returnTodoGroups = new ArrayList<>();
        try {
            returnTodoGroups = new GetTodoGroupsAsyncTask(mDao, GET_N).execute(tempTodoGroup).get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return returnTodoGroups;
    }
    public TodoGroup get(long id) {
        TodoGroup tempTodoGroup = new TodoGroup(id);
        TodoGroup returnTodoGroup = null;
        try {
            returnTodoGroup = new GetTodoGroupAsyncTask(mDao, GET_1).execute(tempTodoGroup).get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return returnTodoGroup;
    }
    public TodoGroup get(String name, long parentId) {
        TodoGroup tempTodoGroup = new TodoGroup(name, parentId);
        TodoGroup returnTodoGroup = null;
        try {
            returnTodoGroup = new GetTodoGroupAsyncTask(mDao, GET_1_NAME).execute(tempTodoGroup).get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return returnTodoGroup;
    }

    public List<TodoGroup> getChildren(long parentId) {
        TodoGroup tempTodoGroup = new TodoGroup("", parentId);
        List<TodoGroup> returnTodoGroups = new ArrayList<>();
        try {
            returnTodoGroups = new GetTodoGroupsAsyncTask(mDao, GET_N_CHILDREN).execute(tempTodoGroup).get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        return returnTodoGroups;
    }

    public int insert(TodoGroup todoGroup) {
        long insertId = -1;

        try {
            insertId = new SetAndReturnTodoGroupAsyncTask(mDao, INSERT_1).execute(todoGroup).get();
        } catch (ExecutionException e) {
            e.printStackTrace();
        } catch (InterruptedException e) {
            e.printStackTrace();
        }

        return (int) insertId;
    }
    public void insert(List<TodoGroup> todoGroups) {
        new SetTodoGroupAsyncTask(mDao, INSERT_N)
                .execute(todoGroups.toArray(new TodoGroup[0]));
    }

    public void update(TodoGroup todoGroup) {
        new SetTodoGroupAsyncTask(mDao, UPDATE_1).execute(todoGroup);
    }
    public void update(List<TodoGroup> todoGroups) {
        new SetTodoGroupAsyncTask(mDao, UPDATE_N)
                .execute(todoGroups.toArray(new TodoGroup[0]));
    }

    // Update Database
    public void delete(long id) {
        delete(get(id));
    }
    public void delete(TodoGroup todoGroup) {
        todoGroup.setIsDelete(1);
        update(todoGroup);
    }
    public void delete(List<TodoGroup> todoGroups) {
        for (TodoGroup todoGroup : todoGroups) todoGroup.setIsDelete(1);
        update(todoGroups);
    }

    // Remove Database
    public void remove(long id) {
        TodoGroup todoGroup = new TodoGroup(id);
        remove(todoGroup);
    }
    public void remove(TodoGroup todoGroup) {
        new SetTodoGroupAsyncTask(mDao, REMOVE_1).execute(todoGroup);
    }
    public void remove(List<TodoGroup> todoGroups) {
        new SetTodoGroupAsyncTask(mDao, REMOVE_N)
                .execute(todoGroups.toArray(new TodoGroup[0]));
    }
    public void remove() {
        TodoGroup todoGroup = new TodoGroup();   // Dummy data
        new SetTodoGroupAsyncTask(mDao, REMOVE_ALL).execute(todoGroup);
    }
}
