package com.freeman.freetodo3.todo.group.view.adapter;

import android.content.Context;
import android.support.annotation.NonNull;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;

import com.freeman.freetodo3.R;
import com.freeman.freetodo3.todo.group.model.TodoGroup;
import com.multilevelview.MultiLevelAdapter;
import com.multilevelview.MultiLevelRecyclerView;
import com.multilevelview.models.RecyclerViewItem;

import java.util.List;

public class TodoGroupManagerAdapter extends MultiLevelAdapter {
    private static final String LOG_TAG = "[TGMA]";

    private static final int FAVORITE_CHECK_COLOR = 0xFFEE3333;
    private static final int FAVORITE_NONCHECK_COLOR = 0xFFDDDDDD;

    private final MultiLevelRecyclerView mThisMainView;
    private final LayoutInflater mInflater;
    private final float mDensity;
    private List<TodoGroupItem> mItems;

    public TodoGroupManagerAdapter(
            Context context,
            List<TodoGroupItem> todoGroupItems,
            MultiLevelRecyclerView multiLevelRecyclerView) {
        super(todoGroupItems);

        this.mThisMainView = multiLevelRecyclerView;
        this.mInflater = LayoutInflater.from(context);
        mDensity = context.getResources().getDisplayMetrics().density;
        mItems = todoGroupItems;
    }

    @Override
    public ThisViewHolder onCreateViewHolder(ViewGroup parent, int viewType) {
        View view = mInflater.inflate(R.layout.todogroup_manager_main_item, parent, false);
        Log.d(LOG_TAG, "TodoGroup ItemView Created..");
        return new ThisViewHolder(view);
    }

    @Override
    public void onBindViewHolder(RecyclerView.ViewHolder holder, int position) {
        ThisViewHolder viewHolder = (ThisViewHolder) holder;

        TodoGroupItem item = mItems.get(position);
        TodoGroup todoGroup = item.getTodoGroup();

        ((ViewGroup.MarginLayoutParams)
                viewHolder.mmItemLayout.getLayoutParams())
                        .leftMargin = (int) (todoGroup.getDepth() * 20 * mDensity);

        viewHolder.mmColorDisplay.setColorFilter(todoGroup.getColor());
        viewHolder.mmNameText.setText(todoGroup.getName());

        if (!todoGroup.isChildren()) {
            viewHolder.mmChildrenShow.setVisibility(View.INVISIBLE);
        }

        if (todoGroup.isFavorite()) {
            viewHolder.mmFavorite.setColorFilter(FAVORITE_CHECK_COLOR);
            viewHolder.mmFavorite.setImageResource(R.drawable.ic_heart);
        } else {
            viewHolder.mmFavorite.setColorFilter(FAVORITE_NONCHECK_COLOR);
            viewHolder.mmFavorite.setImageResource(R.drawable.ic_heart_broken);
        }

        Log.d(LOG_TAG, "Data Binding end: " + todoGroup.toString());
    }

    @Override
    public int getItemCount() {
        return mItems != null ? mItems.size(): 0;
    }

    private class ThisViewHolder extends RecyclerView.ViewHolder {

        private LinearLayout mmItemLayout;
        private ImageView mmColorDisplay;
        private TextView mmNameText;
        private ImageView mmChildrenShow;
        private ImageView mmFavorite;

        public ThisViewHolder(@NonNull View itemView) {
            super(itemView);

            mmItemLayout = itemView.findViewById(R.id.todogroup_manager_main_item);
            mmColorDisplay = itemView.findViewById(R.id.todogroup_manager_main_item_color);
            mmNameText = itemView.findViewById(R.id.todogroup_manager_main_item_todogroup_name);
            mmChildrenShow = itemView.findViewById(R.id.todogroup_manager_main_item_children_show);
            mmFavorite = itemView.findViewById(R.id.todogroup_manager_main_item_favorite);

            mmChildrenShow.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    mThisMainView.toggleItemsGroup(getAdapterPosition());
                    mmChildrenShow.animate()
                            .rotation(mItems.get(getAdapterPosition()).isExpanded() ? -180: 0)
                            .start();
                }
            });
        }

    }
}
